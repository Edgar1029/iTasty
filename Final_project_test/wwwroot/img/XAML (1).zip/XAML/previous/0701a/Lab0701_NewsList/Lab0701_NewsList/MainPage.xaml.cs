﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage.Streams;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Web.Http;

// 空白頁項目範本已記錄在 https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x404

namespace Lab0701_NewsList
{
    /// <summary>
    /// 可以在本身使用或巡覽至框架內的空白頁面。
    /// </summary>
    public sealed partial class MainPage : Page
    {

        private ObservableCollection<News> _newsList = new ObservableCollection<News>();

        public ObservableCollection<News> newsList {
            get { return this._newsList; }
        }

        public MainPage()
        {
            this.InitializeComponent();

            newsList.Add(new News() { NewsId = 1, Title = "work A", Ymd = "2021-05-01" });
            newsList.Add(new News() { NewsId = 2, Title = "work B", Ymd = "2021-05-02" });
            newsList.Add(new News() { NewsId = 3, Title = "work C", Ymd = "2021-05-03" });

            downloadNewsList();
        }

        async void downloadNewsList() {
            HttpClient hc = new HttpClient();

            Uri uri = new Uri("http://localhost:30146/api/news");

            var result = await hc.GetAsync(uri);
            string jsonContent = await result.Content.ReadAsStringAsync();

            // report.Text = jsonContent;

            var newsArray = JsonConvert.DeserializeObject<News[]>(jsonContent);
            
            newsList.Clear();
            foreach (var newsItem in newsArray) {
                newsList.Add(newsItem);
            }

            //var dlg = new ContentDialog() {
            //    Content = JsonConvert.SerializeObject(newsArray),
            //    CloseButtonText = "OK"
            //};
            //await dlg.ShowAsync();

        }

        private News editItem = null;

        private void EditButton_Click(object sender, RoutedEventArgs e) {
            int targetId = Convert.ToInt32((sender as Button).Tag);
            editItem = newsList.FirstOrDefault(o => o.NewsId == targetId);
            if (editItem == null) {
                return;
            }
            titleTextBox.Text = editItem.Title;
            ymdTextBox.Text = editItem.Ymd;
            formPopup.IsOpen = true;
        }


        private async void OkButton_Click(object sender, RoutedEventArgs e) {
            formPopup.IsOpen = false;
            if (editItem == null) {
                // hc.PostAsync()
                var dlg = new ContentDialog() {
                    Content = "POST data coding here",
                    CloseButtonText = "OK"
                };
                await dlg.ShowAsync();
                return;
            }

            formPopup.IsOpen = false;
            editItem.Title = titleTextBox.Text;
            editItem.Ymd = ymdTextBox.Text;

            // report.Text = JsonConvert.SerializeObject(editItem);

            HttpClient hc = new HttpClient();

            Uri uri = new Uri("http://localhost:30146/api/news/" + editItem.NewsId.ToString());

            HttpStringContent content = new HttpStringContent(
                JsonConvert.SerializeObject(editItem),
                UnicodeEncoding.Utf8,
                "application/json");

            var result = await hc.PutAsync(uri, content);

            downloadNewsList();
        }

        private void CreateItem_Click(object sender, RoutedEventArgs e) {
            titleTextBox.Text = "";
            ymdTextBox.Text = "";
            editItem = null;
            formPopup.IsOpen = true;
        }
    }

    public partial class News {
        public int NewsId { get; set; }
        public string Ymd { get; set; }
        public string Title { get; set; }
    }
}
