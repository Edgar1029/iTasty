﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Xml;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// 空白頁項目範本已記錄在 https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x404

namespace Lab0624_ReadXML
{
    /// <summary>
    /// 可以在本身使用或巡覽至框架內的空白頁面。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void downloadButton_Click(object sender, RoutedEventArgs e) {
            string sPath = Windows.Storage.AppDataPaths.GetDefault().LocalAppData;
            string fileName = sPath + "\\news.xml";
            txt.Text = fileName;

            System.Net.WebClient objWebClient = new System.Net.WebClient();

            objWebClient.DownloadFile("https://news.ltn.com.tw/rss/all.xml",
                fileName);

            (sender as Button).Content = "OK";
        }

        private void Button_Click(object sender, RoutedEventArgs e) {
            string sPath = Windows.Storage.AppDataPaths.GetDefault().LocalAppData;
            string fileName = sPath + "\\news.xml";
            txt.Text = fileName;

            System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
            doc.Load(fileName);

            var nodeTitle = doc.SelectSingleNode("/rss/channel/title");
            if (nodeTitle == null) {
                lst.Items.Add("Title not found");
                return;
            }
            lst.Items.Add(nodeTitle.InnerText);

            var nodeRss = doc.SelectSingleNode("/rss");
            lst.Items.Add(nodeRss.Attributes["version"].Value);

            var nodeList = doc.SelectNodes("/rss/channel/item");
            foreach (XmlNode node in nodeList) {
                lst.Items.Add(node.SelectSingleNode("./title").InnerText);
            }

        }
    }
}
