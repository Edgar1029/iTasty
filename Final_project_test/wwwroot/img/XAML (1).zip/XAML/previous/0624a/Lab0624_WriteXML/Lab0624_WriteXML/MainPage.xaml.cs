﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// 空白頁項目範本已記錄在 https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x404

namespace Lab0624_WriteXML
{
    /// <summary>
    /// 可以在本身使用或巡覽至框架內的空白頁面。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
        // 16:00 繼續 ---------------------------------------------------------
        private void Button_Click(object sender, RoutedEventArgs e) {
            string sPath = Windows.Storage.AppDataPaths.GetDefault().LocalAppData;
            string fileName = sPath + "\\booklist.xml";
            // string fileName = "c:\\temp\\booklist.xml";
            txt.Text = fileName;
            System.Xml.XmlWriter w = System.Xml.XmlWriter.Create(fileName);

            w.WriteStartElement("booklist");
            for (int i = 1; i <= 9; i++) {
                w.WriteStartElement("book");
                w.WriteAttributeString("bookId", i.ToString());
                w.WriteAttributeString("isbn", i.ToString());
                //w.WriteStartElement("title");
                //  w.WriteAttributeString("bookId", i.ToString());
                //w.WriteString("test test test");
                //w.WriteEndElement();
                w.WriteElementString("title", $"book {i} name");
                w.WriteElementString("price", (i + 500).ToString());
                w.WriteEndElement();
            }
            w.WriteEndElement();

            w.Close();
            (sender as Button).Content = "OK";

        }
    }
}
