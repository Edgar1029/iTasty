﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// 空白頁項目範本已記錄在 https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x404

namespace Lab0625_ComboBox
{
    /// <summary>
    /// 可以在本身使用或巡覽至框架內的空白頁面。
    /// </summary>
    public sealed partial class MainPage : Page
    {

        ObservableCollection<FontFamily> fonts = new ObservableCollection<FontFamily>();

        public MainPage() {
            this.InitializeComponent();

            colorList.Items.Add("Orange");

            fonts.Add(new FontFamily("Arial"));
            fonts.Add(new FontFamily("Courier New"));
            fonts.Add(new FontFamily("Times New Roman"));
        }

        private void colorList_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            // report.Text += colorList.SelectedIndex.ToString();
            report.Text = colorList.SelectedItem as String;
        }

        private void Button_Click(object sender, RoutedEventArgs e) {
            fonts.Add(new FontFamily("System"));
        }
    }
}
