﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// 空白頁項目範本已記錄在 https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x404

namespace Lab0624_Button
{
    /// <summary>
    /// 可以在本身使用或巡覽至框架內的空白頁面。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            // okButton.Click += OkButton_Click;
        }

        private void OkButton_Click(object sender, RoutedEventArgs e) {
            (sender as Button).Content = "Sent.";
        }

        private void Button_Click(object sender, RoutedEventArgs e) {

        }

        private static int _clicks = 0;
        private void Increase_Click(object sender, RoutedEventArgs e) {
            _clicks += 1;
            clickTextBlock.Text = "Number of Clicks: " + _clicks;
        }

        private void Decrease_Click(object sender, RoutedEventArgs e) {
            if (_clicks > 0) {
                _clicks -= 1;
                clickTextBlock.Text = "Number of Clicks: " + _clicks;
            }
        }

        private void AlignmentMenuFlyoutItem_Click(object sender, RoutedEventArgs e) {
            var which = (sender as MenuFlyoutItem).Tag;
            switch (which) {
                case "left":
                    txt.HorizontalAlignment = HorizontalAlignment.Left;
                    break;
                case "center":
                    txt.HorizontalAlignment = HorizontalAlignment.Center;
                    break;
                case "right":
                    txt.HorizontalAlignment = HorizontalAlignment.Right;
                    break;
            }
        }
    }
}
