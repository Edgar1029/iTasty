﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel.Contacts;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;


// 空白頁項目範本已記錄在 https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x404

namespace Lab0701_ListView
{
    /// <summary>
    /// 可以在本身使用或巡覽至框架內的空白頁面。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        // using System.Collections.ObjectModel;
        ObservableCollection<Contact> Contacts = 
            new ObservableCollection<Contact>();

        public MainPage()
        {
            this.InitializeComponent();
            Fruits.Items.Add("Apple");

 
            // Contact objects are created by providing a first name, last name, and company for the Contact constructor.
            // They are then added to the ObservableCollection Contacts.
            Contacts.Add(new Contact("John", "Doe", "ABC Printers"));
            Contacts.Add(new Contact("Jane", "Doe", "XYZ Refridgerators"));
            Contacts.Add(new Contact("Santa", "Claus", "North Pole Toy Factory Inc."));

        }

        private void Button_Click(object sender, RoutedEventArgs e) {
            // Contacts.Clear();

            // foreach (...) {
            Contact obj = new Contact("Jeremy", "Lin", "NBA");
            Contacts.Add(obj);
        }

        private async void EditButton_Click(object sender, RoutedEventArgs e) {
            string targetName = (sender as Button).Tag.ToString();
            // Contact c = Contacts.FirstOrDefault(o => o.Name == targetName);
            var query = from o in Contacts
                        where o.Name == targetName
                        select o;
            Contact c = query.FirstOrDefault();
            if (c == null) {
                return;
            }
            ContentDialog dlg = new ContentDialog() {
                Content = c.Name + " " + c.LastName,   // (sender as Button).Tag,  "OK", (sender as Button).Content
                CloseButtonText = "OK"
            };
            await dlg.ShowAsync();
        }
    }

    public class Contact {
        public Contact(string n, string l, string c) {
            Name = n;
            LastName = l;
            Company = c;
        }
        public string Name { get; set; }
        public string LastName { get; set; }
        public string Company { get; set; }

        public override string ToString() {
            return Name + " " + LastName;
        }
    }


}
