﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

// 空白頁項目範本已記錄在 https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x404

namespace Lab0628_JSON
{
    /// <summary>
    /// 可以在本身使用或巡覽至框架內的空白頁面。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e) {
            TLocation obj = new TLocation() {
                X = 100, Y = 200, Name = "TaiChung"
            };

            string s = JsonConvert.SerializeObject(obj);

            textBox1.Text = s;
        }

        private void button2_Click(object sender, RoutedEventArgs e) {
            string s = textBox1.Text;
            TLocation obj = JsonConvert.DeserializeObject<TLocation>(s);
            textBox1.Text = obj.Name;
        }

        private void button3_Click(object sender, RoutedEventArgs e) {
            string sPath = Windows.Storage.AppDataPaths.GetDefault().LocalAppData;
            string fileName = sPath + "\\nba.txt";
            textBox1.Text = fileName;

            System.Net.WebClient objWebClient = new System.Net.WebClient();
            objWebClient.DownloadFile(
                "http://data.nba.com/json/cms/noseason/scoreboard/20160302/games.json",
                fileName);
            button3.Content = "Download OK";
        }

        private void button4_Click(object sender, RoutedEventArgs e) {
            string sPath = Windows.Storage.AppDataPaths.GetDefault().LocalAppData;
            string fileName = sPath + "\\nba.txt";

            System.IO.StreamReader objStreamReader = new System.IO.StreamReader(fileName);
            string NbaJsonString = objStreamReader.ReadToEnd();
            objStreamReader.Close();

            JObject objJObject = JObject.Parse(NbaJsonString); 
            JToken objToken = objJObject.SelectToken("sports_content.sports_meta.season_meta.calendar_date");
            if (objToken == null) {
                button4.Content = "not found";
                return;
            }
            textBox1.Text += objToken.Value<string>() + "\r\n";

            JToken gameList = objJObject.SelectToken("sports_content.games.game");
            foreach (JToken game in gameList) {
                string line = string.Format("{0}@{1} {2}:{3}",
                    game.SelectToken("visitor").Value<string>("team_key"),
                    game.SelectToken("home.team_key").Value<string>(),
                    game.SelectToken("visitor").Value<string>("score"),
                    game.SelectToken("home").Value<string>("score")
                );

                textBox1.Text += line + "\r\n";
            }

        }
    }

    public class TLocation {
        public int X { set; get; }
        public int Y { set; get; }
        public string Name { set; get; }

        private string Test { set; get; } = "secret";
    }

}
