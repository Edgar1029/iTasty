﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// 空白頁項目範本已記錄在 https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x404

namespace Lab0630_NavigationView
{
    /// <summary>
    /// 可以在本身使用或巡覽至框架內的空白頁面。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private async void NavigationViewControl_ItemInvoked(
            NavigationView sender, 
            NavigationViewItemInvokedEventArgs args) {

            if (args.IsSettingsInvoked) {
                var dlg = new ContentDialog() {
                    Content = "Setting button clicked",
                    CloseButtonText = "OK"
                };
                await dlg.ShowAsync();
                return;
            }

            // switch () { ... } 

            if (args.InvokedItem.ToString() == "AAA") {
                NavigationViewControl.IsSettingsVisible = !NavigationViewControl.IsSettingsVisible;
                return;
            }

            if (args.InvokedItem.ToString() == "BBB") {
                mySubMenu.ShowAt(itemB);
                return;
            }

            if (args.InvokedItem.ToString() == "CCC") {
                string s = args.InvokedItem.ToString();
                var dlg = new ContentDialog() {
                    Content = $"InvokedItem: {s}",
                    CloseButtonText = "OK"
                };
                await dlg.ShowAsync();
                return;
            }


        }
    }
}
