﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WatchClipboard
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        string sLast = "";
        string sLastImageHash = "";

        private void timerWatching_Tick(object sender, EventArgs e)
        {
            if (!chkWatching.Checked)
                return;

            if (Clipboard.ContainsText())
            {
                string sText = Clipboard.GetText();
                if (sText != sLast)
                {
                    txtContent.Text += sText + System.Environment.NewLine; // + System.Environment.NewLine;
                    System.Media.SystemSounds.Asterisk.Play();
                    sLast = sText;
                }
            }

            if (Clipboard.ContainsImage()) {
                Image img = Clipboard.GetImage();
                MemoryStream st = new MemoryStream();
                img.Save(st, System.Drawing.Imaging.ImageFormat.Jpeg);
                byte[] imageContent = st.ToArray();
                System.Security.Cryptography.MD5CryptoServiceProvider md5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
                byte[] hashed = md5.ComputeHash(imageContent);
                string sImageHash = Convert.ToBase64String(hashed);
                if (sImageHash != sLastImageHash) {
                    string sFileName = @"c:\Temp\" + DateTime.Now.ToString("yyyy-MM-dd_HH_mm_ss") + ".jpg";
                    img.Save(sFileName, System.Drawing.Imaging.ImageFormat.Jpeg);
                    System.Media.SystemSounds.Asterisk.Play();
                    sLastImageHash = sImageHash;
                }
            }

        }
    }
}
