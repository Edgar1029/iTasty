var express = require("express");
var app = express();
app.use(express.json());
app.use(express.urlencoded({extended: true}));
app.listen(3000);

app.get("/", function (req, res) {
    res.send("Hello! ");
})

app.get("/test", function (req, res) {
    res.setHeader("content-type", "application/json");
    res.send('{ "x": 100, "y": 200 }');
})

app.post("/testPost", function (req, res) {
    res.setHeader("content-type", "application/json");
    res.send(`Hello! ${req.body.firstName}`);
})


