import './css/style.css';
import 'jquery';

$("#debug").text("OK");
