﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// 空白頁項目範本已記錄在 https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x404

namespace Lab0628_ContentDialog
{
    /// <summary>
    /// 可以在本身使用或巡覽至框架內的空白頁面。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private async void showOK_Click(object sender, RoutedEventArgs e) {
            //ContentDialog okDialog = new ContentDialog();
            //okDialog.Title = "Infomation";
            //okDialog.Content = "No Wifi...";
            //okDialog.CloseButtonText = "OK";
            ContentDialog okDialog = new ContentDialog() {
                Title = "Infomation",
                Content = "No Wifi now.",
                CloseButtonText = "OK"
            };
            ContentDialogResult answer = await okDialog.ShowAsync();
            // if (answer == ContentDialogResult.None)
            (sender as Button).Content = answer.ToString();  // None
        }

        private async void orderButton_Click(object sender, RoutedEventArgs e) {
            ContentDialog dlg = new ContentDialog() {
                Title = "Asking",
                Content = "Listen, watch, and play in high definition for only $9.99/month. Free to try, cancel anytime.",
                PrimaryButtonText = "Subscribe",
                SecondaryButtonText = "Try it free",
                CloseButtonText = "Close",
                DefaultButton = ContentDialogButton.Primary
            };
            ContentDialogResult answer = await dlg.ShowAsync();
            //switch (answer) {
            //    case ContentDialogResult.Primary:
            //        orderButton.Content = "Order OK";
            //        break;
            //}
            if (answer == ContentDialogResult.Primary) {
                orderButton.Content = "Order OK";
            } else if (answer == ContentDialogResult.Secondary) {
                orderButton.Content = "It's free, have fun";
            } else {
                orderButton.Content = "Cancel";
            }
        }
    }
}
